static analysis rules
