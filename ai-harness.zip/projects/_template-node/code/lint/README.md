code convention rules
